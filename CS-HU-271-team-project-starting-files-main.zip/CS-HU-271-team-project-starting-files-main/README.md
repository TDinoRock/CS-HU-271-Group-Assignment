# CS-HU-271-team-project-starting-files


Teams are free to use any tool to compile and run their java application. 
This project was intended to work with [intellij](https://www.jetbrains.com/idea/) and gradle.

