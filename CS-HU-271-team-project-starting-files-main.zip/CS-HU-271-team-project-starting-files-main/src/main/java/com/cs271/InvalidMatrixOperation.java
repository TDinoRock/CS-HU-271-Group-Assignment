package com.cs271;

public class InvalidMatrixOperation extends Exception {
    public InvalidMatrixOperation(String message) {
        super(message);
    }
}
